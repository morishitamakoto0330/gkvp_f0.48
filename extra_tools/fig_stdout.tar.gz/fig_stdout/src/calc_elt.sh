#!/bin/sh

tail -n 68 ../log/*.000000.0.log.001 > wrk.txt

awk '
  {
    rows[NR]=$0
  }
  END{
    for (i= 3;i<=13;i++){print rows[ i] >> "elt_coarse.dat"}

    for (i= 6;i<= 7;i++){print rows[ i] >> "elt_medium.dat"}
    for (i=17;i<=34;i++){print rows[ i] >> "elt_medium.dat"}
                         print rows[13] >> "elt_medium.dat"

    for (i= 6;i<= 7;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=17;i<=19;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=38;i<=46;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=21;i<=23;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=47;i<=58;i++){print rows[ i] >> "elt_fine.dat"}
                         print rows[28] >> "elt_fine.dat"
    for (i=59;i<=61;i++){print rows[ i] >> "elt_fine.dat"}
                         print rows[30] >> "elt_fine.dat"
    for (i=62;i<=64;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=32;i<=33;i++){print rows[ i] >> "elt_fine.dat"}
    for (i=65;i<=67;i++){print rows[ i] >> "elt_fine.dat"}
                         print rows[13] >> "elt_fine.dat"
  }' wrk.txt

mv *.dat ./data

rm wrk.txt

